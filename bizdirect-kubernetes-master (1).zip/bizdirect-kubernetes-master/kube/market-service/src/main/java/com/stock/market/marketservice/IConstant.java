package com.stock.market.marketservice;

public interface IConstant {
  String SERVICE_DOMAIN = System.getenv("SERVICES_DOMAIN") == null ? "" : ("." + System.getenv("SERVICES_DOMAIN"));
  static final String STOCK_SERVICE = "http://stock-service" + SERVICE_DOMAIN + ":8080";

}

    
