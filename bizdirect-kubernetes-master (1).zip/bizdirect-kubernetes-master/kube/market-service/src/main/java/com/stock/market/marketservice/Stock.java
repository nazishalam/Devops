package com.stock.market.marketservice;

public class Stock {
  public int id;
  public String name;
  public double value;
}