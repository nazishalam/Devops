package com.stock.service.stockservice;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StockController {
  
  @GetMapping("/google")
  public Stock getStock() {
    Stock stock = new Stock();

    stock.id = 20;
    stock.name = "Google";
    stock.value = 3.3;

    return stock;
  }

  @GetMapping("/market/stock")
  public Stock getMarketStock() {
    Stock stock = new Stock();

    stock.id = 20;
    stock.name = "Market";
    stock.value = 3.3;

    return stock;
  }

  
}